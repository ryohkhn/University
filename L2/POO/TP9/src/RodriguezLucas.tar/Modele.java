import java.awt.*;

public class Modele{
    public Color color;

    public Modele(int red,int green,int blue){
        this.color=new Color(red,green,blue);
    }
}
