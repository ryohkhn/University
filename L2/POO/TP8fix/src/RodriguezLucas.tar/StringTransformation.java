public interface StringTransformation{
    String transf(String s);
}
