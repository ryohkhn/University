public class Ex1 {
    // 1. Le type d'entrée de la méthode main est un tableau de type string
    // Le type de sortie est une exception


    // 2. Méthode qui affiche le nombre d'arguments donnés en entrée

    public static void afficheArg(String[] args){
        System.out.println(args.length);
    }

    // 3. On utilise String.length() pour calculer la taille d'une chaîne de caractères

    // 4. La méthode hypot appartient à la classe Math
}
