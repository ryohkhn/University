public class ChaineCar{

    public int len(){
        return 0;
    }

    @Override
    public String toString(){
        return "";
    }
}
