import java.awt.*;
import java.util.LinkedHashMap;

public class Modele{
    // map qui stocke les couleurs ainsi que chaque id
    public LinkedHashMap<Integer,Color> list=new LinkedHashMap<>();
}
