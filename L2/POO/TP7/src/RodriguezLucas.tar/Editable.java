import java.util.Scanner;

public interface Editable{
    void editer(Scanner sc, boolean echo);
}
