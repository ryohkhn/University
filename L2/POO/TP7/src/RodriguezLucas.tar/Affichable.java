public interface Affichable{
    void afficher();
}
