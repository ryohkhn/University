public class Predicat{
    public boolean estVrai(Media m){
        return false;
    }
}
