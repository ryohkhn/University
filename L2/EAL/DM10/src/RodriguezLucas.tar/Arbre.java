public class Arbre{
    public Noeud racine;

    public Arbre(Noeud racine){
        this.racine=racine;
    }
}
