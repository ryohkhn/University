public class Main {

    public static void main(String[] args) {
        Automate test=new Automate("##--##-##--",true);
        test.nEtapes(4);
    }
}
